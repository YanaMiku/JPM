const util = require('util');

module.exports = {
	name: "add",
	param: "<tag/reply chat>",
	cmd: ["add"],
	category: "group",
	desc: "To add members in a group",
	group: true,
	admin: true,
	botAdmin: true,
	async handler(m, { conn, admin, prefix, args }) {
        try {
          if(m.quoted) {
            let _user = m.quoted.sender;
            conn.groupParticipantsUpdate(m.chat, [_user], 'add').then(res => m.reply(util.format(res))).catch(err => m.reply(util.format(err)))
          } else if(args.length >= 1 || m.mentions.length >= 1) {
            if(args.length < 1) return m.reply(`example: ${prefix+m.command ? m.command : ''} 628xxx, +6285-2335-xxxx, 085236xxx`)
            let _participants = args.join(' ').split`,`.map(v => tool.formatPhone(v.replace(/[^0-9]/g, '')))
            let users = (await Promise.all(_participants.filter(async x => { (await conn.onWhatsApp(x)).map(x => x.exists) })))
            conn.groupParticipantsUpdate(m.chat, users, 'add').then(res => m.reply(util.format(res))).catch(err => m.reply(util.format(err)))
          } else {
            m.reply(`tag user atau reply pesan nya, contoh : ${prefix + m.command ? prefix + m.command : ''} @user`)
          };
        } catch (err) {
            m.reply(util.format(err))
        };
    },
};