module.exports = {
    name: 'unbanchat',
    cmd: ['unbanchat', 'unmute'],
    category: 'group',
    desc: 'mute chat in group',
    group: true,
    admin: true,
    async handler(m, {conn, text}){
        await db.read()
        if(!text) return m.reply("idnya mana?")
        if(!db.data.mute.includes(text)) return m.reply(`Bot tidak dimute di group sebelumnya! dengan id ${text}`)
        db.data.mute.splice(db.data.mute.indexOf(text), 1)
        await db.write()
        m.reply(`Bot diunmute digroup tersebut! dengan id ${text}`)
    }
}