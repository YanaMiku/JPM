const fs = require("fs");
const path= require("path")

module.exports = {
	name: "cmdloader",
	cmd: ["cmdloader"],
	category: "owner",
	owner: true,
	async handler(m, { conn, text}) {
	    await conn.sendReact(m.from, '⏱️', m.key);
	
const ReadFitur = () => {
  let pathdir = path.join(__dirname, "../../commands");
  let fitur = fs.readdirSync(pathdir);
  for (let fold of fitur) {
    for (let filename of fs.readdirSync(pathdir + `/${fold}`)) {
      plugins = require(path.join(pathdir + `/${fold}`, filename));
      plugins.function ? (attr.functions[filename] = plugins) : (attr.commands[filename] = plugins);
    }
  }
  m.reply("Command loaded successfully");
};

await ReadFitur()
await conn.sendReact(m.from, '☑️', m.key);
	},
};