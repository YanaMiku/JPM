const fs = require("fs");
const { exec } = require("child_process");
module.exports = {
	name: "restart",
cmd: ["restart"],
	category: "owner",
	async handler(m, { conn, body, isOwner}) {
		const util = require("util");
	await conn.sendReact(m.from, "⏱️", m.key)
				exec(`npm restart`, async (err, stdout) => {
					if (err) return await m.reply(String(err));
					await m.reply(stdout);
				});
await conn.sendReact(m.from, "☑️", m.key)
await m.reply("Bot Berhasil Di Restart!")
}
}