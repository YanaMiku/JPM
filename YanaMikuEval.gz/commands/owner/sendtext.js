const fs = require('fs')
module.exports = {
name: 'sendtext',
cmd: ['sendtext'],
category: 'owner',
owner: true,
query: 'Mau kirim ke mana? private ? atau group ? Dan Silahkan tulis id dan | text yang ingin di kirim!\ncontoh: #sendtext private 6281361057300 | halo kak',
async handler(m, {conn, text, args}){
await conn.sendReact(m.from, "⏱️", m.key)
await m.reply(response.wait)
let t = text.split(' ')[1];
let te = text.split('|');
if(!text.split('|')) return await m.reply("gunakan pembatasan | saat mengirimkan text\nExample:\n#sendtext private 6281361057300 | halo kak")

if(args[0] === "private"){
  await conn.sendMessage(`${t}`+"@s.whatsapp.net", {text: `${te}`, }, {quoted: m})
  await m.reply("berhasil!")
} else if(args[0] === "group"){
  await conn.sendMessage(`${t}`+"@g.us", {text: `${te}`, }, {quoted: m})
await conn.sendReact(m.from, "☑️", m.key)
  await m.reply("berhasil!")
}
}
}