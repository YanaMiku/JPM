const fs = require('fs');

module.exports = {
name: 'refreshfile',
cmd: ['refreshfile'],
category: 'owner',
owner: true,
query: 'lokasi filenya mana',
async handler(m, { conn, text }) {
await conn.sendReact(m.from, '⏱️', m.key);
await m.reply(response.wait)
nocache('./'+text, module => {
  m.reply(`File './'+${text} has updated!\nRestarting!`)
    process.send("reset")
})
   
function nocache(module, cb = () => { }) {
    m.reply(`Module ${module} is now Watched`)
	  fs.watchFile(require.resolve(module), async() => {
	    await uncache(require.resolve(module))
	    cb(module)
	  })
  };

function uncache(module = '.') {
  	return new Promise((resolve, reject) => {
	    try {
	   	  delete require.cache[require.resolve(module)]
	  	  resolve()
	    } catch (e) {
	  	  reject(e)
	    }
	  })
  };
await conn.sendReact(m.from, '☑️', m.key);
await m.reply("berhasil!")
}
}