const moment = require('moment-timezone')
const util =require('util');
module.exports = {
	name: 'listgroup2',
	cmd: ['listgroup2', 'listgc2'],
	category: 'owner',
	desc: 'Get listgroup On the Bot Account',
	owner: true,
	async handler(m, {conn}){
		const anu = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
let h = 1;
        let teks = `📄Total Group : ${anu.length} Group\n\n`
		for (let i of anu) {
			let metadata = await conn.groupMetadata(i).catch((e) => m.reply(util.format(e)))
			teks += `${h++}. *ID:* ${metadata.id}\n`
		}
 		await m.reply(teks, {withTag: true})
	}
}