const fs = require("fs");
module.exports = {
	name: "addfile",
	param: "<reply code>",
	cmd: ["addfile"],
	category: "owner",
	owner: true,
	quoted: true,
	async handler(m, { conn, text }) {
	    conn.sendReact(m.from, '⏱️', m.key);
		const file = `./${text}`;
		await fs.writeFileSync(file, m.quoted.text);
		m.reply("Succsess add file " + text);
		conn.sendReact(m.from, '☑️', m.key);
	},
};