const fs = require('fs');

module.exports = {
name: 'refreshcmd',
cmd: ['refreshcmd'],
category: 'owner',
owner: true,
query: 'lokal command nya apa?',
async handler(m, { conn, text }) {
await conn.sendReact(m.from, '⏱️', m.key);
let stdio = './commands/'+`${text}`
nocache(stdio, module => {
  m.reply(`File ${stdio} has updated!\nRestarting!`)
    process.send("reset")
})
   
function nocache(module, cb = () => { }) {
    m.reply(`Module ${module} is now Watched`)
	  fs.watchFile(require.resolve(module), async() => {
	    await uncache(require.resolve(module))
	    cb(module)
	  })
  };

function uncache(module = '.') {
  	return new Promise((resolve, reject) => {
	    try {
	   	  delete require.cache[require.resolve(module)]
	  	  resolve()
	    } catch (e) {
	  	  reject(e)
	    }
	  })
  };
await conn.sendReact(m.from, '☑️', m.key);
}
}