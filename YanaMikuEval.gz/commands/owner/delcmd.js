const fs = require("fs");
module.exports = {
	name: "delcommand",
	param: "<text>",
	cmd: ["delcommand", "delcmd"],
	category: "owner",
	owner: true,
	async handler(m, { conn, text}) {
	    conn.sendReact(m.from, '🕒', m.key);
		const file = `./commands/${text}`;
		await fs.rm(file);
		m.reply("Succsess delete command " + text);
	},
};