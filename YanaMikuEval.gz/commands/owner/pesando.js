const fs = require('fs')
const PhoneNumber = require('awesome-phonenumber') 

module.exports = {
  name: 'pesando',
  cmd: ['pesando'],
  category: 'owner',
  owner: true,
  query: 'textnya mana kak',
  async handler(m, {conn, text}){
    if(!m.quoted.text) return await m.reply("silahkan reply pesan dari owner di private chat bot! lalu dilanjutkan dengan pesanmu!")
    if(!text) return await m.reply("textnya mana?")
    await conn.sendReact(m.from, "⏱️", m.key)
    await m.reply(response.wait)
    let getCode = PhoneNumber(m.quoted.text.split('•')[3].split("@")[1]).g.number.input.split('+')[1]
    let res_1 = getCode.split(' ')[0]
    let res_2 = getCode.split('-')[0]
    let res_3 = getCode.split('-')[1]
    let res_4 = getCode.split('-')[2]
    let unlimited = 9999999
    let $ = res_1+res_2+res_3+res_4
    $.slice(5, unlimited)
    let results = getCode.split(" ")[0].replace($, '')
    let layer = res_2+res_3+res_4
    let sjjs = results+layer
    let gz = sjjs.slice(5, unlimited)
    let negae = "62"
    let neg = negae+gz
    await conn.sendMessage(`${neg}`+"@s.whatsapp.net", { text: `${text}` })
    await conn.sendReact(m.from, "☑️", m.key)
    await m.reply("berhasil!")
  }
}