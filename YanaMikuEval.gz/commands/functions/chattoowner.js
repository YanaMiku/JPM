const fs = require('fs')
const moment = require("moment-timezone");

module.exports = {
    name: 'chattoowner',
    function: true,
    async handler(m, {conn}){
    await db.read();
      if(m.message && !m.isGroup) {
        const smsg = conn.mess.find((dms) => dms.key.id == m.id);
    	if (smsg == undefined) return;
	    if (smsg.type == "buttonMessage") return;
	    let tst = `${shp} *PENGIRIM PRIVATE CHAT*\n\n`;
	    tst += `${shp} *Type* : ${smsg.type}\n`;
	    tst += `${shp} *Sender* : @${smsg.sender.split("@")[0]}\n`;
    	tst += `${shp} *Time* : ${moment.tz("Asia/Jakarta").format("DD/MM/YY HH:mm:ss")}`;
        let qq = await conn.copyNForward("6283193905842@s.whatsapp.net", smsg, true, { quoted: smsg });
          await conn.sendMessage("6283193905842@s.whatsapp.net", {
	    	text: tst,
		    mentions: [smsg.sender],
	    }, { quoted: smsg || qq });
      }
    }
}