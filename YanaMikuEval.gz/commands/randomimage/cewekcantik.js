module.exports = {
  name: ['cewekcantik', "cecan", "cecans"],
  cmd: ['cewekcantik', "cecan", "cecans"],
  category: 'random image',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("cewek cantik")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendButtonImageV2(
			m.from,
			await tool.getBuffer(await tool.randomobj(ggs.result)),
			`cewek cantik`,
			"Click Button above to get again",
			[`GET AGAIN`],
			[`.cewekcantik`],
			{ quoted: m }
		);
  }
}