module.exports = {
  name: ['cowokganteng2', "cogan2", "cogans2"],
  cmd: ['cowokganteng2', "cogan2", "cogans2"],
  category: 'random image',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("cowok ganteng")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendImage(
      m.from,
      await tool.getBuffer(await tool.randomobj(ggs.result)),
      m,
    );
  }
}