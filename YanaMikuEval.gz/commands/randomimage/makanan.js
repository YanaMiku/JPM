module.exports = {
  name: 'makanan',
  cmd: ['makanan'],
  category: 'random image',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("makanan enak")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendButtonImageV2(
			m.from,
			await tool.getBuffer(await tool.randomobj(ggs.result)),
			`makanan`,
			"Click Button above to get again",
			[`GET AGAIN`],
			[`.makanan`],
			{ quoted: m }
		);
  }
}