module.exports = {
  name: 'memeindo',
  param: '<query>',
  cmd: ['memeindo'],
  category: 'random image',
  query: true,
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("meme indo"+`${text}`)
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendButtonImageV2(
			m.from,
			await tool.getBuffer(await tool.randomobj(ggs.result)),
			`meme indo: ${text}`,
			"Click Button above to get again",
			[`GET AGAIN`],
			[`.memeindo ${text}`],
			{ quoted: m }
		);
  }
}