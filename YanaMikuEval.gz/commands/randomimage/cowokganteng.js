module.exports = {
  name: ['cowokganteng', "cogan", "cogans"],
  cmd: ['cowokganteng', "cogan", "cogans"],
  category: 'random image',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("cowok ganteng")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendButtonImageV2(
			m.from,
			await tool.getBuffer(await tool.randomobj(ggs.result)),
			`cowok ganteng`,
			"Click Button above to get again",
			[`GET AGAIN`],
			[`.cowokganteng`],
			{ quoted: m }
		);
  }
}