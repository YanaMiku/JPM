module.exports = {
  name: 'meme2',
  cmd: ['meme2'],
  category: 'random image',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("meme")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendImage(
      m.from,
      await tool.getBuffer(await tool.randomobj(ggs.result)),
      m,
    );
  }
}