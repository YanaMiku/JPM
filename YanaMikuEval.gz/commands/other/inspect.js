module.exports = {
	name: "inspect",
	cmd: ["inspect"],
	ignored: true,
	query: true,
  category: "general",
	async handler(m, { conn, prefix, text}) {
	const moment = require('moment-timezone')
	if(!text) return m.reply("mana idnya?")
	let v = await conn.groupMetadata(text)
	let b = `*INSPECTOR GROUP*\n\n`
	b += `*Id:* ${v.id}\n`
	b += `*judul:* ${v.subject}\n`
	b += `*Owner:* ${v.owner.split("@")[0]}\n`
	b += `*Dibuat:* ${moment(v.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n`
	b += `*Anggota:* ${v.size}\n`
	b += `*deskripsi:* ${v.desc != undefined ? v.desc: '-'}\n`
	await m.reply(b)
	},
}