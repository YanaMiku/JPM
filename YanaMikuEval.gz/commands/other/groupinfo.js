module.exports = {
	name: "groupinfo",
	cmd: ["groupinfo", "infogc"],
	ignored: true,
category: "general",
	async handler(m, { conn, prefix }) {
	const moment = require('moment-timezone')
const _meta = await conn.groupMetadata(m.chat)
            let _img;
            try { 
                _img = await conn.profilePictureUrl(_meta.id, 'image') 
            } catch { 
                _img = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTCOJ-GLOg6NwRz1yTKcFE9w8FKwzqgjSSXNg&usqp=CAU' 
            }
            let yyy = `${_meta.subject} - Created by @${_meta.subjectOwner.split('@')[0]} on ${moment(_meta.creation * 1000).format('ll')}\n\n*${_meta.participants.length}* Total Members\n*${_meta.participants.filter(x => x.admin === 'admin').length}* Admin\n*${_meta.participants.filter(x => x.admin === null).length}* Not Admin\n\nGroup ID : ${_meta.id}`
            await conn.sendImage(m.chat, await (await node_fetch(_img)).buffer(), yyy, m, { mentions: [_meta.owner] })
	},
}