const fs = require('fs');
const fetch = require('node-fetch');

module.exports = {
  name: 'truth',
  cmd: ['truth'],
  category: 'game',
  desc: 'Truth or Dare!',
  async handler(m, {conn}){ 
    var truth = await bochil.truth()
    var txt = `*• Truth!*\n\n`
    txt += `${truth}` 
    var footer = `Patuhi aturan mainya dong, gaberani?`
    conn.sendButtonImageV2(m.from, await (await fetch("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlgNgSaE8CCk2SdTlZ0-uvpOFmlirhK2uRKw&usqp=CAU")).buffer(), txt, footer, ['Truth', 'Dare'], ['.truth', '.dare'], {isLoc: true})		
    }
}