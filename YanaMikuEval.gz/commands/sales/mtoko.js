const fs = require("fs");
const prettyms = require('pretty-ms');
const { showhit } = require("../../database/hit");

module.exports = {
  name: 'mtoko',
  cmd: ['mtoko', 'toko', 'menutoko'],
  category: 'sales',
  owner: true,
  desc: "Menampilkan Toko mu dengan cara Memasukkan Id",
  async handler(m, { conn, prefix, chats, isAdmin, args, isBotAdmin }) {
	await db.read();
	try {
	if (
	  db.data.toko[m.sender] != undefined &&
	  !db.data.toko[m.sender].status == true
	) return m.reply("Maaf anda belum membuat toko anda sendiri, Silahkan hubungi #owner untuk membuat toko jualan anda")
	await conn.sendReact(m.from, '⏱️', m.key)
	let listSerch = [{
	  title: `Halo ${db.data.toko[m.sender].username}`, 
      rows: [ 
        {
          title: "Cek Status", 
          rowId: `.tokocekstatus`, 
          description: `• Status Toko Jualan Mu!`,
        }, { 
          title: "Menu Toko", 
          rowId: `.tokomenu`, 
          description: `• Menampilkan Menu`,
        }
      ]
    }]
    const dates = new Date()
    const hit = Object.values(await showhit()).map((ht) => ht.total);
	const thit = await eval(hit.join(" + "));
	let menu = `Pengguna ${db.data.toko[m.sender].username}, Berikut Ini Adalah Toko Jualanmu!\nSemoga Laris Yah 😊\n`
	menu += `*${shp} Status:* Aktif!\n`;
	menu += `*${shp} Hit:* ${thit}\n`;
	menu += `*${shp} Prefix:* [ ${prefix} ]\n`;
    menu += `*${shp} Pada:* ${dates.toLocaleDateString("pt-id")}\n`
 	menu += `*${shp} Waktu:* ${dates.toLocaleTimeString("pt-id")}\n`
    var listMessage = {
      text: menu,
      footer: config.botname.toUpperCase(),
      title: `*${m.user.jadibot ? await conn.getName(await decodeJid(conn.user.id)).toUpperCase() : config.botname.toUpperCase()}*\n`,
      buttonText: "Click Here",
      sections: listSerch,
      mentions: []
    }
    await conn.sendMessage(m.from, listMessage, {quoted: m})
    await conn.sendReact(m.from, '☑️', m.key)
    } catch (error) {
     if(error.Error === "TypeError") { return m.reply("Maaf anda belum membuat toko anda sendiri, Silahkan hubungi #owner untuk membuat toko jualan anda") }
    }
  },
};