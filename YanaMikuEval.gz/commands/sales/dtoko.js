module.exports = {
    name: "daftartoko",
    param: "<username|password>",
    cmd: ["daftartoko", "dtoko"],
    category: "Sales",
    desc: `Create Toko`,
    admin: true,
    query: true,
    async handler(m, {
        conn,
        args,
        text
    }) {
        await db.read();
        if(!text.split('|')[0]) return m.reply("username nya apa ?")
        if(!text.split('|')[1]) return m.reply("kata sandi nya mana ?")
        if(!text.split('|')[2]) return m.reply("sender nya mana ? (contoh: 6281361057300@s.whatsapp.net)")
            if (
                db.data.toko[text.split('|')[2]] != undefined &&
				db.data.toko[text.split('|')[2]].status == true
			) return m.reply(`toko tersebut sudah pernah di buat sebelumnya!\nStatus: ${db.data.toko[text.split('|')[2]].status ? "Online!" : "Offline!"}`);
            db.data.toko[text.split('|')[2]] = {
              username: text.split('|')[0],
              password: text.split('|')[1],
              status: true
            };
            await db.write();
            m.reply(`Toko Berhasil Di buat Dengan Username: *${db.data.toko[text.split('|')[2]].username}*, dan password: *${db.data.toko[text.split('|')[2]].password}*`);
    },
};