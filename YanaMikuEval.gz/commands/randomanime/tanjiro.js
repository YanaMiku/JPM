module.exports = {
  name: ['tanjirokamado', "tanjiro"],
  cmd: ['tanjirokamado', 'tanjiro'],
  category: 'random anime',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("tanjiro kamado")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendButtonImageV2(
			m.from,
			await tool.getBuffer(await tool.randomobj(ggs.result)),
			`tanjiro kamado`,
			"Click Button above to get again",
			[`GET AGAIN`],
			[`.tanjirokamado`],
			{ quoted: m }
		);
  }
}