module.exports = {
  name: ['itsukinakano2', "itsuki2"],
  cmd: ['itsukinakano2', 'itsuki2'],
  category: 'random anime',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("itsuki nakano")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendImage(
      m.from,
      await tool.getBuffer(await tool.randomobj(ggs.result)),
      m,
    );
  }
}