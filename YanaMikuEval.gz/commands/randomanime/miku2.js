module.exports = {
  name: ['mikunakano2', "miku2"],
  cmd: ['mikunakano2', 'miku2'],
  category: 'random anime',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("miku nakano")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendImage(
      m.from,
      await tool.getBuffer(await tool.randomobj(ggs.result)),
      m,
    );
  }
}