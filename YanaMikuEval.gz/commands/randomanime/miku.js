module.exports = {
  name: ['mikunakano', "miku"],
  cmd: ['mikunakano', 'miku'],
  category: 'random anime',
  async handler(m, {conn, text}){
    conn.sendReact(m.from, '🕒', m.key)
    const ggs = await scrapp.googleImg("miku nakano")
    if(!ggs.status) return m.reply('Image not found')
    await conn.sendButtonImageV2(
			m.from,
			await tool.getBuffer(await tool.randomobj(ggs.result)),
			`miku nakano`,
			"Click Button above to get again",
			[`GET AGAIN`],
			[`.mikunakano`],
			{ quoted: m }
		);
  }
}